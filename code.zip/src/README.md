# Installation
```
pip install transformers datasets accelerate
```
# Run
```
bash run.sh
```